import {
  MatFormFieldModule
} from "./chunk-75VU2SNK.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-B5NCJBFJ.js";
import "./chunk-V65GLZI2.js";
import "./chunk-CHDDVX6R.js";
import "./chunk-4Z6LSBK7.js";
import "./chunk-WTLARL7A.js";
import "./chunk-R7WLEI4C.js";
import "./chunk-KVL7JR6F.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-3DVDYWL7.js";
import "./chunk-KULNP5IU.js";
import "./chunk-FGTMUVC6.js";
import "./chunk-PXYB4HYX.js";
import "./chunk-VN4676WM.js";
import "./chunk-44EGZ73U.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
